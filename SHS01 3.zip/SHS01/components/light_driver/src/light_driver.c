/*
 * SPDX-FileCopyrightText: 2021-2025
 * SPDX-License-Identifier: CC0-1.0
 *
 * Light driver for Zigbee On/Off + Level control.
 * Adapted for Seeed Studio XIAO ESP32C6 on-board USER LED.
 *
 * Notes:
 * - XIAO ESP32C6 on-board LED is on GPIO15 (set via CONFIG_GPIO_LED_ON_DEVKIT).
 * - LED is typically active-low (set via CONFIG_GPIO_LED_ACTIVE_LOW).
 */

#include "light_driver.h"

static const char *TAG = "light_driver";

#include "esp_err.h"
#include "esp_log.h"
#include "driver/ledc.h"
#include "driver/gpio.h"

/* Kconfig */
#ifndef CONFIG_GPIO_LED_ON_DEVKIT
#define CONFIG_GPIO_LED_ON_DEVKIT 15
#endif

#ifndef CONFIG_GPIO_LED_ACTIVE_LOW
#define CONFIG_GPIO_LED_ACTIVE_LOW 1
#endif

#define LED_GPIO        CONFIG_GPIO_LED_ON_DEVKIT
#define LED_ACTIVE_LOW  CONFIG_GPIO_LED_ACTIVE_LOW

/* LEDC config: 8-bit duty gives level (0..255) naturally */
#define LEDC_MODE       LEDC_LOW_SPEED_MODE
#define LEDC_TIMER      LEDC_TIMER_0
#define LEDC_CHANNEL    LEDC_CHANNEL_0
#define LEDC_DUTY_RES   LEDC_TIMER_8_BIT
#define LEDC_FREQ_HZ    5000

static bool    s_power = false;
static uint8_t s_level = 255; /* 0..255 brightness */

static inline uint32_t duty_max(void)
{
    return (1u << LEDC_DUTY_RES) - 1u; /* 255 for 8-bit */
}

static uint32_t compute_duty(bool power, uint8_t level)
{
    /* Interpret "level" as brightness: 0=off .. 255=max */
    uint32_t max = duty_max();
    uint32_t scaled = power ? (uint32_t)level : 0u;  /* 0..255 */

#if LED_ACTIVE_LOW
    /* Active-low LED: duty 0 => always low => ON; duty max => always high => OFF */
    return max - scaled;
#else
    /* Active-high LED: duty 0 => OFF; duty max => ON */
    return scaled;
#endif
}

static void apply_output(void)
{
    uint32_t duty = compute_duty(s_power, s_level);
    ESP_ERROR_CHECK(ledc_set_duty(LEDC_MODE, LEDC_CHANNEL, duty));
    ESP_ERROR_CHECK(ledc_update_duty(LEDC_MODE, LEDC_CHANNEL));
}

void light_driver_init(bool power)
{
    s_power = power;
    s_level = 255;

    ESP_LOGI(TAG, "LED GPIO=%d active_low=%d", LED_GPIO, (int)LED_ACTIVE_LOW);

    ledc_timer_config_t timer_cfg = {
        .speed_mode       = LEDC_MODE,
        .timer_num        = LEDC_TIMER,
        .duty_resolution  = LEDC_DUTY_RES,
        .freq_hz          = LEDC_FREQ_HZ,
        .clk_cfg          = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&timer_cfg));

    ledc_channel_config_t ch_cfg = {
        .gpio_num   = LED_GPIO,
        .speed_mode = LEDC_MODE,
        .channel    = LEDC_CHANNEL,
        .intr_type  = LEDC_INTR_DISABLE,
        .timer_sel  = LEDC_TIMER,
        .duty       = compute_duty(false, 0), /* start OFF */
        .hpoint     = 0,
    };
    ESP_ERROR_CHECK(ledc_channel_config(&ch_cfg));

    apply_output();
}

void light_driver_set_power(bool power)
{
    s_power = power;
    apply_output();
}

void light_driver_set_level(uint8_t level)
{
    s_level = level;
    apply_output();
}

/* Single-color LED: ignore color setters */
void light_driver_set_color_RGB(uint8_t red, uint8_t green, uint8_t blue)
{
    (void)red; (void)green; (void)blue;
}

void light_driver_set_color_xy(uint16_t color_current_x, uint16_t color_current_y)
{
    (void)color_current_x; (void)color_current_y;
}

void light_driver_set_color_hue_sat(uint8_t hue, uint8_t sat)
{
    (void)hue; (void)sat;
}
