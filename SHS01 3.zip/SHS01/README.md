Firmware sanitized.
Power Config fixed (mains device).
